# Design

## High Level Design 
### State Diagram of Inbuild Function:
![State Diagram of Inbuild Function:](https://user-images.githubusercontent.com/78848562/107875685-5a837f00-6ee7-11eb-9629-ff9064a72354.png)
![Activity UML Diagram](https://user-images.githubusercontent.com/78853934/107880566-af35f280-6f05-11eb-8e66-00a0b97d4932.png)
### class diagram in structure
![class UML Diagram in structure](https://user-images.githubusercontent.com/78849172/107894860-20ea5c80-6f57-11eb-9876-c9360de479a4.png))

## Low Level Design 


### Strctural Diagram of Angular and Cartesion
![Strctural Diagram of Angular and Cartesion](https://user-images.githubusercontent.com/78848562/107875693-640ce700-6ee7-11eb-9b71-18550bba448c.png)
### Structural Diagram of Mathematical Operations-square,cube,square root,cube root,factorial
![Structural Class Diagram](https://user-images.githubusercontent.com/78853934/107879661-2cf6ff80-6f00-11eb-8464-2f8c03e83f01.png)
### Deployement structural Diagram for storing the previous result
![structural diagram for low level](https://user-images.githubusercontent.com/78849172/107895144-49bf2180-6f58-11eb-9354-be61658f4e02.png)


### Behavioral Diagram of Cartesion and Angular
![FeaturesBehaviouralDiagram](https://user-images.githubusercontent.com/78848562/107875700-6ec77c00-6ee7-11eb-9c3d-0081dad57d0f.png)
## Behavioral Diagram of Mathematical Operations-square,cube,square root,cube root,factorial
![Use Diagram](https://user-images.githubusercontent.com/78853934/107879719-85c69800-6f00-11eb-98f2-9689f65a620e.png)
### Behavioral Diagram for conversting degree to radian & viceversa
![state diagram](https://user-images.githubusercontent.com/78849172/107895181-6a877700-6f58-11eb-9192-1c1ae2aecb09.png)
### usecase diagram for all the high level requirements
![use case3725](https://user-images.githubusercontent.com/78849373/107902236-e0e1a480-6f6b-11eb-8e95-caeacdd5bde1.png)
###  usecase diagram for basic arithmetic operations
![use case](https://user-images.githubusercontent.com/78849373/107902256-ea6b0c80-6f6b-11eb-894e-f9bd81d74aa5.png)
### activity diagram for basic arithmetic operations
![activity diagram](https://user-images.githubusercontent.com/78849373/107902264-efc85700-6f6b-11eb-9d2a-7de463b226ae.png)
### component diagram for basic arithmetic operations
![component diagram](https://user-images.githubusercontent.com/78849373/107902286-ffe03680-6f6b-11eb-8585-f88488a58747.png)





