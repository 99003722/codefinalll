# Requirements
## Introduction
 A calculator is a machine which allows people to do math operations more easily. For example, most calculators will add, subtract, multiply, and divide. Some also do square roots, and more complex calculators can help with calculus and draw function graphs. Calculators are found everywhere

## Research
Reaearch on various calculators are done which are present in the market like scientific calculator, Graphing calculator, Abacus, Basic calculator and thier functions are also studied.
## Cost and Features
![CostvsFeatures](https://user-images.githubusercontent.com/78853934/107878897-a93b1400-6efb-11eb-9c9e-0d3f0f156910.PNG)


## Defining Our System
  The system do all arithmetic operations,and it calculates square root ,power ,cube ,factorial and it can able to convert a value from degree to 
  radians and degree to radians as well.It is very helpful for engineering students and merchants and in financing people etc.
## SWOT ANALYSIS
![SWOT-Sample](https://user-images.githubusercontent.com/78848562/107878936-e4d5de00-6efb-11eb-9fe8-31c22b60387e.png)

# 4W&#39;s and 1&#39;H

## Who:

Students and research people.

## What:

Advance programmable calculator

## When:

For calculations in signal processing and simple calculations.

## Where:

Research work and iterative work

## How:

By using the built in functions.

# Detail requirements
## High Level Requirements:
-- ID | Description | Status (Implemented/Future) | Owner

- HL_1 | Arithmetic Operations | Implemented | Sai kalki
- HL_2 | Mathematical Operations | Implemented | Archita
- HL_3 | Mensuration Calculations | Implemented | Aryan
- HL_4 | Conversion | Implemented | Shiva


##  Low level Requirements:
-- ID | Description | Status (Implemented/Future) | Owner
- LL_1.1 | Addition | Implemented | Sai kalki
- LL_1.2 | Subtraction | Implemented | Sai kalki
- LL_1.3 | Multiplication | Implemented | Sai kalki
- LL_1.4 | Division | Implemented | Sai kalki
- LL_2.1 | Square | Implemented | Archita
- LL_2.2 | Cube | Implemented | Archita
- LL_2.3 | Square root | Implemented | Archita
- LL_2.4 | Cube root | Implemented | Archita
- LL_2.5 | Factorial | Implemented | Archita
- LL_3.1 | Area of circle | Implemented | Aryan
- LL_3.2 | Area of rectangle | Implemented | Aryan
- LL_3.3 | Area of triangle | Implemented | Aryan
- LL_4.1 | Polar to rectangular | Implemented | Aryan
- LL_4.2 | Rectangular to polar | Implemented | Aryan
- LL_4.3 | Radians to degree | Implemented | Shiva
- LL_4.4 | Degree to radian | Implemented | Shiva
- LL_4.5 | Storing of data | Implemented | Shiva
