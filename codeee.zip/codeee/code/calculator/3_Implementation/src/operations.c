#include <operations.h>
#include<math.h>

double square1(double sq)
{
    return sq*sq;
}

double cube1(double cu)
{
    return cu*cu*cu;
}

double square_root(double sq_rt)
{
    return sqrt(sq_rt);
}

double cube_root(double cb_rt)
{
    return cbrt(cb_rt);
}


