#ifndef __INBUILD_H__
#define __INBUILD_H__

#include <stdio.h>
#include <stdlib.h>
#include<math.h>
#include<string.h>

float Area_Of_Triangle(float side_1,float side_2,float side_3);
float Perimeter_Of_Triangle(float side_1,float side_2,float side_3);
float Area_Of_Circle(float radius);
float Perimeter_Of_Circle(float radius);

#endif  /* #define __OPERATIONS_H__ */