#ifndef __CONVERSION_H__
#define __CONVERSION_H__

#include <stdio.h>
#include <stdlib.h>
#include<math.h>

#include<string.h>
float Degree(float rad);
float Radian(float degree);

#endif 